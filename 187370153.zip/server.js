var http = require('http');
var fs = require("fs");

var qs = require('querystring');
var MongoClient = require('mongodb').MongoClient;
var dbUrl = "mongodb://127.0.0.1:27017/";
//test
var mongo = require('mongodb');	//Gen ObjectId必須
var ObjectID = mongo.ObjectID;
//test

http.createServer(function(request, response) {

	if(request.url==="/"){
		response.end('<script>location.href="/index";</script>');
		/*
		var abc='Peter';
		console.log("Requested URL is url" +request.url);
		response.writeHead(200, {'Content-Type': 'text/html'});
		response.write('<b>Hey there!</b><br /><br />This is the default response. Requested URL is: ' + request.url + '<br />');
		response.end('<script>alert("SendEnd'+abc+'");</script>');
		//response.end('alert("Hello Node.JS World!");');
		*/
	}
	else if(request.url==="/test"){
		if(request.method === "POST") {
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
					response.write("Txt01"+"&");
				return request.on('end', function() {
					response.end("Txt_02");
				});
			});
		}
	}
	else if(request.url==="/addtofavlist"){
		if(request.method === "POST") {
            console.log("Add data to favourite list");
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				return request.on('end', function() {
					var d=formData.split("＆");
					MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb_187370153");
						var new_objid = new ObjectID();
						console.log("New ObjectId: "+new_objid);
						var myobj={"_id":new_objid,uid:d[0],udata:d[1]};
						console.log("uid: "+d[0]);
						console.log("udata: "+d[1]);
						
						dbo.collection("memb_favlst").insertOne(myobj, function(err, res) {
							if (err) throw err;
							console.log("1 document inserted");
							db.close();
							response.end("Add to Favourite list completed.");
						});
						
						response.end("Add to Favourite list completed.");
					});
				});
			});
		}
	}
	else if(request.url==="/loadfavlst"){
		if(request.method === "POST") {
            console.log("Load data from favourite list");
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get user_id from client side:\n"+formData);
				return request.on('end', function() {
						MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
							if (err) throw err;
							var dbo = db.db("mydb_187370153");
							dbo.collection("memb_favlst").find({},{uid:data, projection:{uid:0}}).toArray(function(err, result) {
								if (err) throw err;
								console.log(result);
								db.close();
								//console.log(result[0].udata);
								//console.log(result[1].udata);
								for (var i in result){
									response.write(result[i]._id+"＆"+result[i].udata+"＆");
								}
								response.end("Load Favlst completed");
							});
						});
				});
			});
		}
	}
	//------
	else if(request.url==="/rmvfavlst"){
		if(request.method === "POST") {
            console.log("Remove data from favourite list");
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				var datasp= formData.split("＆");
				console.log("_id:"+datasp[0]);
				console.log("uid:"+datasp[1]);
				console.log("Remove favourite list from server");
				return request.on('end', function() {
						MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
							if (err) throw err;
							var dbo = db.db("mydb_187370153");
							//var myquery={"_id":datasp[0],uid:datasp[1]};
							//dbo.collection("memb_favlst").find({},{uid:data, projection:{uid:0}}).toArray(function(err, result) {
							dbo.collection("memb_favlst").deleteOne({_id:ObjectID(datasp[0])}, function(err, obj) {
								if (err) throw err;
								console.log("1 document deleted");
								db.close();
								//console.log(result[0].udata);
								//console.log(result[1].udata);
								response.end("Remove record completed");
							});
						});
				});
			});
		}
	}
	//------
	
	
	else if(request.url==="/testpage"){
		sendFileContent(response, "testpage.html", "text/html");
	}
	else if(request.url==="/testpagebtn"){
		if(request.method === "POST") {
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				var rawdata = fs.readFileSync('./raw/Fitness_Rooms.json');
				return request.on('end', function() {
				response.end(rawdata);
				});
			});
		}
	}
	else if(request.url==="/getFWTData"){
		if(request.method === "POST") {
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				//let rawdata = fs.readFileSync('./raw/EventHK.json');
				var rawdata = fs.readFileSync('./raw/1_Fitness_Walking_Tracks.json');
				return request.on('end', function() {
				response.end(rawdata);
				});
			});
		}
	}
	else if(request.url==="/getPlyRmsData"){
		if(request.method === "POST") {
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				var rawdata = fs.readFileSync('./raw/2_Children\'s Play Rooms.json');
				return request.on('end', function() {
				response.end(rawdata);
				});
			});
		}
	}
	else if(request.url==="/getGymRmsData"){
		if(request.method === "POST") {
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				var rawdata = fs.readFileSync('./raw/3_Fitness_Rooms.json');
				return request.on('end', function() {
				response.end(rawdata);
				});
			});
		}
	}
	else if(request.url==="/regacc"){
		if(request.method === "POST") {
            console.log("Register the new member by POST");
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get data from client side:\n"+formData);
				return request.on('end', function() {
					//var user;	//有咩用？
					var d=formData.split("&");
					MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb_187370153");
						//test gen objid
						var new_objid = new ObjectID();
						console.log("New ObjectId: "+new_objid);
						//test
						var myobj={"_id":new_objid,uname:d[1],uemail:d[3],upasswd:d[5]};
						//test
						dbo.collection("member").countDocuments({uemail:d[3]}, function(err, count) {
							if (err) throw err;
							console.log(count);
							if (count !== 0){
								response.end("This EMail has already registered\nPlease use other EMail Address to Registering");
								//console.log("Debug01");
								db.close();
							}else{
								dbo.collection("member").insertOne(myobj, function(err, res) {
									if (err) throw err;
									console.log("1 document inserted");
									//console.log("Debug02");
									db.close();
									response.end(new_objid+"&Registration completed.\nWelcome, "+d[1]+",\nand it changes to member mode automatically.");
								});
							}
						});
					});
				});
			});
		}
	}
	else if(request.url==="/login"){
		if(request.method === "POST") {
            console.log("Some people would like to login by POST");
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get login data from client side:\n"+formData);
				return request.on('end', function() {
					var z=formData.split("&");	//[0]: uemail / [1]:upasswd
					MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb_187370153");
						console.log(z[0]);
						console.log(z[1]);
						dbo.collection("member").findOne({uemail:z[0],upasswd:z[1]},function(err, findres) {	//InsertOne //用db.collection.count({uemail:"CTM@gmail.co"})去搵出有冇已REG的RECORD。
						//if (err) throw err;
							if (!findres){
								db.close();
								response.end("Login Fail");
							}else{
								response.write(findres._id+"&");	//成功試到
								response.write(findres.uname+"&");
								response.end("Login Completed");
								db.close();
							}
						});
					});
				});
			});
		}
	}
	else if(request.url==="/renewinfo"){
		console.log("Member would like to update account information");	//server.js debug用
		if(request.method === "POST") {
            console.log("Some people would like to login by POST");
			formData = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get update data from client side:\n"+formData);
				return request.on('end', function() {
					MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb_187370153");
						var updata=formData.split("＆");
						dbo.collection("member").findOne({_id:new ObjectID(updata[0])},function(err, findres) {	//InsertOne //用db.collection.count({uemail:"CTM@gmail.co"})去搵出有冇已REG的RECORD。
							if (findres.upasswd == updata[1]){
									var updateinfo = {_id:new ObjectID(updata[0])};
									console.log(updata[2]);
									var newvalues = { $set: qs.parse(updata[2]) };
									dbo.collection("member").updateOne(updateinfo, newvalues, function(err, res) {
										if (err) throw err;
										console.log("1 document updated");
										response.end("Information Update completed.\nPlease logout and login to confirm it.");
										db.close();
									});
									//*/
							}else{
								db.close();
								response.end("Login Password invalid.\nPlease input again.");
							}
						});
					});
				});
			});
		}
	}
	else if(request.url==="/console"){
		console.log("Load console page");	//server.js debug用
		sendFileContent(response, "console.html", "text/html");
	}
	else if(request.url==="/getemail"){	//未完成
		if(request.method === "POST") {
            //console.log("Someone would like to login by POST");
			formData = '';
			//msg = '';
			return request.on('data', function(data) {
				formData += data;
				console.log("Get login data from client side:\n"+formData);
				return request.on('end', function() {
					//var z=formData.split("&");	//[0]: uemail / [1]:upasswd
					MongoClient.connect(dbUrl,{ useNewUrlParser: true }, function(err, db) {
						if (err) throw err;
						var dbo = db.db("mydb_187370153");
						//console.log(z[0]);
						//console.log(z[1]);
						dbo.collection("member").findOne({_id:new ObjectID(formData)},function(err, findres) {	//InsertOne //用db.collection.count({uemail:"CTM@gmail.co"})去搵出有冇已REG的RECORD。
							response.end(findres.uemail);
							db.close();
						});
					});
				});
			});
		}
	}
	else if(request.url==="/index"){
		console.log("Load index page");	//server.js debug用
		sendFileContent(response, "index.html", "text/html");
	}
	else if(/^\/[-_a-zA-Z0-9\/]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.easing.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.bundle.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.min.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.woff$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.woff2$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.ttf$/.test(request.url.toString())){
		//sendFileContent(response, request.url.toString().substring(1), "text/css");
		sendFileContent(response, request.url.toString().substring(1), "application/x-font-ttf");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.jpg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/jpg");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.png$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/png");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.svg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/svg+xml");
	}
	else if(/^\/[-a-zA-Z0-9\/]*.txt$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/txt");
	}
	else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(80)
//}).listen(8080)
//}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){	//
			console.log(err);	//在後臺會顯示err
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}